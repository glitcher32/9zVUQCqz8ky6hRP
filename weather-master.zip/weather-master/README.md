# 🌤weather⛅
A simple responsive weather app.

This react app is the final outcome of the my react beginner tutorial series.

**Want to build this awesome weather app by yourself?**  
**Want to learn react?**  
**Head over to [this post](https://medium.com/bit-shift/react-beginner-part-i-1e44330294f6) and start building.**

This React tutorial series covers all the basics of React like component's props and state, lifecycles, event handling, state lifting, conditional rendering plus you will learn how to setup a custom webpack config for a react app and how to deploy it on Github Pages.  
**The end result of this series is a responsive and functional weather app deployed on GitHub pages.**
