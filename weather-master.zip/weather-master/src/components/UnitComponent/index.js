import UnitComponent from './UnitComponent.jsx';

export default UnitComponent;