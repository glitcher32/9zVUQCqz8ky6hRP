import GraphComponent from './GraphComponent.jsx';

export default GraphComponent;