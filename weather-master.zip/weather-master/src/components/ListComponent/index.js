import ListComponent from "./ListComponent.jsx";

export default ListComponent;