import SearchBox from './SearchBox.jsx';

export default SearchBox;